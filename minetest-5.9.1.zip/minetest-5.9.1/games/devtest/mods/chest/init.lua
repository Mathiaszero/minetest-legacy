dofile(minetest.get_modpath("chest").."/chest.lua")
dofile(minetest.get_modpath("chest").."/detached.lua")
